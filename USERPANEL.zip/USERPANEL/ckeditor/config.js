CKEDITOR.editorConfig = function (config) {
    config.toolbar = [
        { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript'] },
        { name: 'styles', items: ['Format', 'Font', 'FontSize'] },
		{ name: 'paragraph', items: ['NumberedList', 'BulletedList'] },
        { name: 'paragraph', items: ['Outdent', 'Indent'] },
        { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock'] },
		{ name: 'insert', items: ['Image', 'Table', 'HorizontalRule'] },
        { name: 'links', items: ['Link', 'Unlink'] },
        { name: 'insert', items: ['SpecialChar','TextColor'] },
        { name: 'document', items: ['Source'] },
		{ name: 'tools', items: ['Maximize'] }
    ];
};